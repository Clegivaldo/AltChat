import request from 'src/service/request'

export function ListarAvaliacoes(params) {
  return request({
    url: '/ratings',
    method: 'get',
    params
  })
}

export function ListarAvaliacoesMedia(params) {
  return request({
    url: '/ratings/average',
    method: 'get',
    params
  })
}
