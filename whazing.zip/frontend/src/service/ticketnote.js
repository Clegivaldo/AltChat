import request from 'src/service/request'

export function CriarNote (data) {
  return request({
    url: '/ticket-notes/',
    method: 'post',
    data
  })
}

export function ListarNotesTickets(ticketId) {
  return request({
    url: '/ticket-notes/list/',
    method: 'get',
    params: { ticketId } // Passa o parâmetro diretamente
  })
}

export function ListarNotesContact(contactId) {
  return request({
    url: '/ticket-notes/contact/list/',
    method: 'get',
    params: { contactId } // Passa o parâmetro diretamente
  })
}

export function DeletarNote (data) {
  return request({
    url: `/ticket-notes/${data.id}`,
    method: 'delete'
  })
}

export function ListarNote(params) {
  return request({
    url: '/ticket-notes',
    method: 'get',
    params
  })
}
