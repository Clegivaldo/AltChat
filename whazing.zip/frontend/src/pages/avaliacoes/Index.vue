<template>
  <div v-if="userProfile === 'admin'">
    <q-table
      class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
      :class="{
    'full-height': $q.screen.lt.sm
  }"
      title="Avaliações"
      :data="ratings"
      :columns="columns"
      :loading="loading"
      row-key="id"
      virtual-scroll
      :virtual-scroll-item-size="48"
      :virtual-scroll-sticky-size-start="48"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]"
      @virtual-scroll="onScroll"
    >
      <template v-slot:top-left>
        <div>
          <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="star" class="q-pr-sm"/>
            Avaliações
          </h2>

          <div class="row q-col-gutter-md">
            <!-- Média das Avaliações - Lado Esquerdo -->
            <div class="col-12 col-md-4">
              <q-card class="bg-primary text-white">
                <q-card-section>
                  <div class="row items-center">
                    <div class="col">
                      <div class="text-h6">Média das Avaliações</div>
                      <div class="text-h4">{{ averageRating.toFixed(1) }} / 5.0</div>
                    </div>
                    <div class="col">
                      <q-rating
                        v-model="averageRating"
                        size="2em"
                        color="yellow"
                        readonly
                      />
                    </div>
                  </div>
                </q-card-section>
              </q-card>
            </div>

            <!-- Filtros - Lado Direito -->
            <!-- Modify the filters section in your template -->
            <div class="col-12 col-md-8">
              <div class="row q-col-gutter-md">
                <!-- User filter -->
                <div class="col-12 col-md-6">
                  <q-select
                    v-model="filters.userId"
                    :options="usuarios"
                    option-value="id"
                    option-label="name"
                    label="Filtrar por Usuário"
                    outlined
                    dense
                    clearable
                    @input="onFilterChange"
                  />
                </div>

                <!-- Channel filter -->
                <div class="col-12 col-md-6">
                  <q-select
                    v-model="filters.whatsappId"
                    :options="whatsapps"
                    emit-value
                    map-options
                    option-value="id"
                    option-label="name"
                    label="Canal"
                    outlined
                    dense
                    clearable
                    @input="onFilterChange"
                  />
                </div>

                <!-- Date filters in a separate row -->
                <div class="col-12">
                  <div class="row q-col-gutter-md">
                    <div class="col-12 col-md-6">
                      <p>Data Inicial:</p>
                      <DatePick
                        dense
                        outlined
                        v-model="filters.startDate"
                        @input="onFilterChange"
                      />
                    </div>
                    <div class="col-12 col-md-6">
                      <p>Data Final:</p>
                      <DatePick
                        dense
                        outlined
                        v-model="filters.endDate"
                        @input="onFilterChange"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-12">
              <div class="row q-col-gutter-md">
                <div class="col" v-for="(stat, index) in ratingStats" :key="index">
                  <q-card class="text-center">
                    <q-card-section>
                      <div class="text-h6">{{ stat.emoji }}</div>
                      <div class="text-subtitle1">{{ stat.label }}</div>
                      <div class="text-h5">{{ stat.count }}</div>
                    </q-card-section>
                  </q-card>
                </div>
              </div>
            </div>

          </div>
        </div>
      </template>

      <template v-slot:body-cell-ticketId="props">
        <q-td :props="props">
          <button
            class="q-mr-sm"
            @click.prevent="visualizarChat(props.row.ticketId)"
          >
            <i class="fa fa-comments"></i> {{ props.row.ticketId }}
          </button>
        </q-td>
      </template>

      <!-- Template para a coluna de avaliação -->
      <template v-slot:body-cell-rate="props">
        <q-td :props="props">
          <q-rating
            v-model="props.row.rate"
            size="1.5em"
            color="yellow"
            readonly
          />
        </q-td>
      </template>

      <!-- Template para a coluna de data -->
      <template v-slot:body-cell-createdAt="props">
        <q-td :props="props">
          {{ formatDate(props.row.createdAt) }}
        </q-td>
      </template>
    </q-table>

    <!-- Modal de Chat -->
    <ChatModal v-if="mostrarModal" :ticketId="String(ticketIdAtual)" @close="fecharChatModal" />

  </div>
</template>

<script>
import { date } from 'quasar'
import { ListarAvaliacoes, ListarAvaliacoesMedia } from 'src/service/avaliacoes'
import { ListarUsuarios } from 'src/service/user'
import { ListarCores } from 'src/service/configuracoesgeneral'
import ChatModal from 'src/pages/relatorios/ChatModal.vue'
import { mapGetters } from 'vuex'

export default {
  name: 'Avaliações',
  components: {
    ChatModal
  },
  data () {
    return {
      ratingStats: [
        { emoji: '🤩', label: 'Extremamente Satisfeito', count: 0, rating: 5 },
        { emoji: '😊', label: 'Muito Satisfeito', count: 0, rating: 4 },
        { emoji: '🙂', label: 'Satisfeito', count: 0, rating: 3 },
        { emoji: '🙁', label: 'Insatisfeito', count: 0, rating: 2 },
        { emoji: '😞', label: 'Muito Insatisfeito', count: 0, rating: 1 }
      ],
      ratings: [],
      averageRating: 0,
      userProfile: 'user',
      mostrarModal: false,
      loading: false,
      userId: null,
      usuarios: [],
      whatsappNumbers: [],
      filters: {
        userId: null,
        whatsappId: null,
        startDate: null,
        endDate: null
      },
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        page: 1,
        hasMore: true
      },
      columns: [
        { name: 'ticketId', label: 'Ticket', field: 'ticketId', align: 'left' },
        {
          name: 'rate',
          label: 'Avaliação',
          field: 'rate',
          align: 'center',
          sortable: true
        },
        {
          name: 'userName',
          label: 'Usuário Avaliado',
          field: row => row.user?.name,
          align: 'left'
        },
        {
          name: 'contactName',
          label: 'Contato',
          field: row => row.contact?.name,
          align: 'left'
        },
        {
          name: 'createdAt',
          label: 'Data',
          field: 'createdAt',
          align: 'center',
          sortable: true
        }
      ]
    }
  },
  computed: {
    ...mapGetters([
      'whatsapps'
    ])
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Chamada para o backend
        const response = await ListarCores()

        // Desestruturação dos valores retornados pela API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar as cores como variáveis CSS no :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Erro ao carregar as cores:', error)
      }
    },
    formatDate(dateString) {
      return date.formatDate(dateString, 'DD/MM/YYYY HH:mm')
    },
    async listarUsuarios() {
      const data = await ListarUsuarios()
      this.usuarios = data.data.users
    },
    fecharChatModal () {
      this.mostrarModal = false
    },
    visualizarChat (ticketId) {
      this.ticketIdAtual = ticketId
      this.mostrarModal = true
    },
    onFilterChange() {
      this.pagination.page = 1
      this.fetchRatings()
    },
    async fetchRatings() {
      this.loading = true
      try {
        const startDate = this.filters.startDate
          ? new Date(this.filters.startDate).toISOString()
          : null

        const endDate = this.filters.endDate
          ? (() => {
            const date = new Date(this.filters.endDate)
            date.setDate(date.getDate() + 1)
            return date.toISOString()
          })()
          : null

        // Reset ratings array when filters change
        if (this.pagination.page === 1) {
          this.ratings = []
        }

        const params = {
          startDate,
          endDate,
          userId: null,
          whatsappId: this.filters.whatsappId,
          pageNumber: this.pagination.page
        }

        if (this.filters.userId && this.filters.userId.id) {
          params.userId = this.filters.userId.id
        }

        const [response, averageResponse] = await Promise.all([
          ListarAvaliacoes(params),
          ListarAvaliacoesMedia(params)
        ])

        if (response.data && Array.isArray(response.data.records)) {
          // When filters change, replace the entire ratings array instead of concatenating
          if (this.pagination.page === 1) {
            this.ratings = response.data.records.map((rating) => ({
              id: rating.id,
              ticketId: rating.ticketId,
              rate: rating.rate,
              user: rating.user,
              contact: rating.contact,
              createdAt: rating.createdAt
            }))
          } else {
            // Only concatenate for pagination
            this.ratings = [
              ...this.ratings,
              ...response.data.records.map((rating) => ({
                id: rating.id,
                ticketId: rating.ticketId,
                rate: rating.rate,
                user: rating.user,
                contact: rating.contact,
                createdAt: rating.createdAt
              }))
            ]
          }

          this.pagination.rowsNumber = response.data.count || 0
          this.pagination.hasMore = response.data.hasMore
          this.averageRating = Number(averageResponse.data) || 0

          // Update rating stats based on current filtered data
          this.ratingStats.forEach(stat => {
            stat.count = this.ratings.filter(r => r.rate === stat.rating).length
          })
        }
      } catch (error) {
        console.error('Erro ao buscar avaliações:', error)
        this.$q.notify({
          type: 'negative',
          message: 'Erro ao carregar avaliações'
        })
      } finally {
        this.loading = false
      }
    },
    onScroll({ to }) {
      if (!this.loading && this.pagination.hasMore && to >= (this.ratings.length - 10)) {
        this.pagination.page++
        this.fetchRatings()
      }
    }
  },
  async mounted() {
    this.loadColors()
    await this.fetchRatings()
    await this.listarUsuarios()
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px

.ratings-table
  height: 85vh

  .q-table__top,
  .q-table__bottom,
  thead tr:first-child th
    background-color: #fff

  thead tr th
    position: sticky
    z-index: 1

  thead tr:last-child th
    top: 63px

  thead tr:first-child th
    top: 0
</style>
