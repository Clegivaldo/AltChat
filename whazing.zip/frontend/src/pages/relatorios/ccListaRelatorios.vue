<template>
  <div class="row q-col-gutter-xl">
  <div v-if="userProfile === 'admin'">
      <div class="row items-center q-mb-md">
        <h2 :class="$q.dark.isActive ? 'color-dark3' : ''">
          <q-icon name="mdi-message-bulleted-off" class="q-pr-sm" />
          Relatórios
        </h2>
      </div>

      <q-card class="q-ma-sm" style="height: calc(100vh - 135px)">
        <q-card-section>
          <div class="row q-col-gutter-md">
            <div v-for="menu in cRelatorios"
                 :key="menu.name"
                 class="col-12 col-sm-6 col-md-4">
              <q-item
                clickable
                v-ripple
                @click="goTo(menu.name)"
                class="shadow-1 full-width report-card"
                style="border-left: solid #3E72AF 3px">
                <q-item-section class="q-pa-md">
                  <q-item-label class="text-primary">{{ menu.titulo }}</q-item-label>
                  <q-item-label caption>{{ menu.objetivo }}</q-item-label>
                </q-item-section>
              </q-item>
            </div>
          </div>
        </q-card-section>
      </q-card>
    </div>
  </div>
</template>

<script>
import relatorios from './relatorios.json'
import { ListarCores } from 'src/service/configuracoesgeneral'
export default {
  name: 'ccListaRelatorios',
  computed: {
    cRelatorios () {
      return relatorios
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Chamada para o backend
        const response = await ListarCores()

        // Desestruturação dos valores retornados pela API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar as cores como variáveis CSS no :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Erro ao carregar as cores:', error)
      }
    },
    async goTo(route) {
      this.$router.push({ name: route })
    }
  },
  data () {
    return {
      userProfile: 'user'
    }
  },
  mounted() {
    this.loadColors()
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>

<style lang="sass">
.report-card
  padding: 20px
  min-height: 120px

  // Opcional: aumentar o tamanho da fonte do título
  .q-item-label.text-primary
    font-size: 1.8rem
    margin-bottom: 8px

  // Opcional: ajustar o tamanho do texto da descrição
  .q-item-label.caption
    font-size: 1.5rem
    line-height: 1.4
</style>
