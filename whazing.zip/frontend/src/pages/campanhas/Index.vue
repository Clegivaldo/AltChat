<template>
  <div v-if="!canAccessPage">
    <q-banner dense inline-actions class="bg-red text-white">
      <template v-slot:avatar>
        <q-icon name="warning" />
      </template>
      Campanhas não fazem parte do seu plano. Para contratar, entre em contato com o suporte.
      <template v-slot:action>
        <q-btn flat
               class="generate-button btn-rounded-50"
               :class="{'generate-button-dark' : $q.dark.isActive}"
               v-if="whatsappNumber"
               icon="mdi-whatsapp"
               label="Chamar Suporte"
               @click="abrirWhatsApp"
        />
      </template>
    </q-banner>
  </div>
  <div v-else-if="userProfile === 'admin'">
    <q-table
      flat
      bordered
      square
      hide-bottom
      class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
      :class="{
    'full-height': $q.screen.lt.sm
  }"
      :data="campanhas"
      :columns="columns"
      :loading="loading"
      row-key="id"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]"
    >
      <template v-slot:top-left>
        <div>
          <h2  :class="$q.dark.isActive ? ('color-dark3') : ''">
          Campanhas
        </h2>
        <div>
        <q-btn
          class="color-light1"
          :class="$q.dark.isActive ? ('color-dark1') : ''"
          icon="refresh"
          outline
          @click="listarCampanhas"
          >
        <q-tooltip>
          Atualizar Listagem
        </q-tooltip>
        </q-btn>
        <q-btn
          class="generate-button btn-rounded-50"
          :class="{'generate-button-dark' : $q.dark.isActive}"
          icon="eva-plus-outline"
          label="Adicionar"
          @click="campanhaEdicao = {}; modalCampanha = true"
        />
        </div>
        </div>

      </template>
      <template v-slot:body-cell-color="props">
        <q-td class="text-center">
          <div
            class="q-pa-sm rounded-borders"
            :style="`background: ${props.row.color}`"
          >
            {{ props.row.color }}
          </div>
        </q-td>
      </template>
      <template v-slot:body-cell-isActive="props">
        <q-td class="text-center">
          <q-icon
            size="24px"
            :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
            :color="props.value ? 'positive' : 'negative'"
          />
        </q-td>
      </template>
      <template v-slot:body-cell-acoes="props">
        <q-td class="text-center">
          <q-btn
        flat
        round
        icon="mdi-account-details-outline"
        class="color-light1"
        :class="$q.dark.isActive ? ('color-dark1') : ''"
        @click="contatosCampanha(props.row)"
      >
        <q-tooltip>
          Lista de Contatos da Campanha
        </q-tooltip>
      </q-btn>
      <q-btn
        flat
        round
        v-if="['pending', 'canceled'].includes(props.row.status)"
        icon="mdi-calendar-clock"
        class="color-light1"
        :class="$q.dark.isActive ? ('color-dark1') : ''"
        @click="iniciarCampanha(props.row)"
      >
        <q-tooltip>
          Programar Envio
        </q-tooltip>
      </q-btn>
      <q-btn
        flat
        round
        v-if="['scheduled', 'processing'].includes(props.row.status)"
        icon="mdi-close-box-multiple"
        class="color-light1"
        :class="$q.dark.isActive ? ('color-dark1') : ''"
        @click="cancelarCampanha(props.row)"
      >
        <q-tooltip>
          Cancelar Campanha
        </q-tooltip>
      </q-btn>
      <q-btn
        flat
        round
        icon="eva-edit-outline"
        class="color-light1"
        :class="$q.dark.isActive ? ('color-dark1') : ''"
        @click="editarCampanha(props.row)"
      >
        <q-tooltip>
          Editar Campanha
        </q-tooltip>
      </q-btn>
      <q-btn
        flat
        round
        icon="eva-trash-outline"
        class="color-light1"
        :class="$q.dark.isActive ? ('color-dark1') : ''"
        @click="deletarCampanha(props.row)"
      >
        <q-tooltip>
          Excluir Campanha
        </q-tooltip>
      </q-btn>
    </q-td>
      </template>
    </q-table>
    <ModalCampanha
      v-if="modalCampanha"
      :modalCampanha.sync="modalCampanha"
      :campanhaEdicao.sync="campanhaEdicao"
      @modal-campanha:criada="campanhaCriada"
      @modal-campanha:editada="campanhaEditada"
    />
  </div>
</template>

<script>
import { CancelarCampanha, DeletarCampanha, IniciarCampanha, ListarCampanhas } from 'src/service/campanhas'
import { MostrarPlano } from 'src/service/empresas'
import ModalCampanha from './ModalCampanha'
import { format, parseISO, startOfDay } from 'date-fns'
import { ListarConfiguracaoPublica } from 'src/service/configuracoesgeneral'

export default {
  name: 'Campanhas',
  components: {
    ModalCampanha
  },
  data () {
    return {
      userProfile: 'user',
      canAccessPage: false,
      campanhaEdicao: {},
      modalCampanha: false,
      whatsappNumber: null,
      campanhas: [],
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      loading: false,
      columns: [
        { name: 'id', label: '#', field: 'id', align: 'left' },
        { name: 'name', label: 'Campanha', field: 'name', align: 'left' },
        { name: 'start', label: 'Início', field: 'start', align: 'center', format: (v) => format(parseISO(v), 'dd/MM/yyyy HH:mm') },
        {
          name: 'status',
          label: 'Status',
          field: 'status',
          align: 'center',
          format: (v) => v ? this.status[v] : ''
        },
        { name: 'contactsCount', label: 'Qtd. Contatos', field: 'contactsCount', align: 'center' },
        { name: 'pendentesEnvio', label: 'À Enviar', field: 'pendentesEnvio', align: 'center' },
        { name: 'pendentesEntrega', label: 'À Entregar', field: 'pendentesEntrega', align: 'center' },
        { name: 'recebidas', label: 'Recebidas', field: 'recebidas', align: 'center' },
        { name: 'lidas', label: 'Lidas', field: 'lidas', align: 'center' },
        { name: 'acoes', label: 'Ações', field: 'acoes', align: 'center' }
      ],
      status: {
        pending: 'Pendente',
        scheduled: 'Programada',
        processing: 'Processando',
        canceled: 'Cancelada',
        finished: 'Finalizada'
      }
    }
  },
  methods: {
    async fetchConfigurations() {
      try {
        const response = await ListarConfiguracaoPublica()
        const configurations = response.data
        this.whatsappNumber = configurations.whatsappnumber || null
      } catch (error) {
        console.error('Erro ao buscar configurações:', error)
      }
    },
    abrirWhatsApp() {
      if (this.whatsappNumber) {
        const url = `https://wa.me/${this.whatsappNumber}?text=Ol%C3%A1%21+quero+adquirir+campanhas`
        window.open(url, '_blank') // Abre o WhatsApp em uma nova aba
      }
    },
    async listarPlano() {
      try {
        const { data } = await MostrarPlano()
        this.canAccessPage = data.campaign !== false
      } catch (error) {
        console.error('Erro ao carregar o plano:', error)
      }
    },
    async listarCampanhas () {
      const { data } = await ListarCampanhas()
      this.campanhas = data
    },
    isValidDate (v) {
      return startOfDay(new Date(parseISO(v))).getTime() >= startOfDay(new Date()).getTime()
    },
    campanhaCriada (campanha) {
      this.listarCampanhas()
    },
    campanhaEditada (campanha) {
      this.listarCampanhas()
    },
    editarCampanha (campanha) {
      if (campanha.status !== 'pending' && campanha.status !== 'canceled') {
        this.$notificarErro('Só é permitido editar campanhas que estejam pendentes ou canceladas.')
      }
      this.campanhaEdicao = {
        ...campanha,
        start: campanha.start, // format(parseISO(campanha.start), 'yyyy-MM-dd'),
        end: campanha.start // format(parseISO(campanha.start), 'yyyy-MM-dd')
      }
      this.modalCampanha = true
    },
    deletarCampanha (campanha) {
      this.$q.dialog({
        title: 'Atenção!!',
        message: `Deseja realmente deletar a Campanha "${campanha.name}"?`,
        cancel: {
          label: 'Não',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Sim',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeletarCampanha(campanha)
          .then(res => {
            let newCampanhas = [...this.campanhas]
            newCampanhas = newCampanhas.filter(f => f.id !== campanha.id)
            this.campanhas = [...newCampanhas]
            this.$notificarSucesso(`Campanha ${campanha.name} deletada!`)
          })
        this.loading = false
      })
    },
    contatosCampanha (campanha) {
      this.$router.push({
        name: 'contatos-campanha',
        params: {
          campanhaId: campanha.id,
          campanha
        }
      })
    },
    cancelarCampanha (campanha) {
      this.$q.dialog({
        title: 'Atenção!!',
        message: `Deseja realmente deletar a Campanha "${campanha.name}"?`,
        cancel: {
          label: 'Não',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Sim',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        CancelarCampanha(campanha.id)
          .then(res => {
            this.$notificarSucesso('Campanha cancelada.')
            this.listarCampanhas()
          }).catch(err => {
            this.$notificarErro('Não foi possível cancelar a campanha.', err)
          })
      })
    },
    iniciarCampanha (campanha) {
      if (!this.isValidDate(campanha.start)) {
        this.$notificarErro('Não é possível programar campanha com data menor que a atual')
      }

      if (campanha.contactsCount == 0) {
        this.$notificarErro('Necessário ter contatos vinculados para programar a campanha.')
      }

      if (campanha.status !== 'pending' && campanha.status !== 'canceled') {
        this.$notificarErro('Só é permitido programar campanhas que estejam pendentes ou canceladas.')
      }

      IniciarCampanha(campanha.id).then(res => {
        this.$notificarSucesso('Campanha iniciada.')
        this.listarCampanhas()
      }).catch(err => {
        this.$notificarErro('Não foi possível iniciar a campanha.', err)
      })
    }
  },
  mounted () {
    this.fetchConfigurations()
    this.listarPlano()
    this.listarCampanhas()
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px
</style>
