<template>
  <div>

    <div class="bg-transparent fast-messages-list" v-if="cMensagensRapidas.length > 0 && ticketFocado.status === 'open'">
      <q-badge class="text-white item-fast-messages-list q-pa-sm" v-for="(resposta, index) in cMensagensRapidas" :key="resposta.key" clickable v-close-popup @click="mensagemRapidaSelecionada(resposta)"
               :class="getBadgeClass(index)">
        <q-item-label class="text-bold">
          {{ resposta.key }}
        </q-item-label>
        <q-tooltip content-class="text-white bg-padrao text-bold" anchor="top middle" self="bottom middle">
          {{ resposta.message }}
        </q-tooltip>
      </q-badge>
    </div>

    <div @drop.prevent="handleFileDrop" @dragover.prevent>
      <div class="drop-area" @drop="handleFileDrop" @dragover="handleDragOver" @dragleave="handleDragLeave">

        <div class="row q-col-gutter-md" v-if="isScheduleDate">
          <div class="col-xs-12 col-md-6">
            <q-select :options="schedule.options" v-model="schedule.selected" map-options outlined @input="onSelectSchedule" />
          </div>
          <div class="col-xs-12 col-md-6">
            <q-datetime-picker outlined stack-label label="Data/Hora Agendamento" mode="datetime" v-model="scheduleDate" format24h :readonly="schedule.selected.value !== 'custom'" />
          </div>
        </div>

        <div class="q-py-md row bg-white justify-start items-center text-grey-9 relative-position">
          <template v-if="!isRecordingAudio">

            <q-btn v-if="$q.screen.width > 500" flat dense icon="mdi-emoticon-happy-outline" :disable="cDisableActions" class="btn-rounded-cor1 q-mx-xs" :class="$q.dark.isActive ? ('btn-rounded-cor1-dark q-mx-xs') : ''">
              <q-tooltip content-class="text-bold"> Emoji </q-tooltip>
              <q-menu anchor="top right" self="bottom middle" :offset="[5, 40]">
                <VEmojiPicker style="width: 40vw" :showSearch="true" :emojisByRow="calculateEmojisByRow()" labelSearch="Localizar..." lang="pt-BR" @select="onInsertSelectEmoji" />
              </q-menu>
            </q-btn>

            <q-btn flat dense round icon="eva-plus-outline"
                   class="color-light1"
                   :class="$q.dark.isActive ? ('color-dark1') : ''"
                   v-if="$q.screen.width > 500">
              <q-menu>
                <q-list style="min-width: 100px;">
                  <q-item class="text-left" style="padding: 0">
                    <q-btn
                      flat
                      @click="abrirEnvioArquivo"
                      icon="mdi-paperclip"
                      :disable="cDisableActions || desabilitarInput"
                      class="btn-rounded-cor1 full-width"
                      :class="$q.dark.isActive ? ('btn-rounded-cor1-dark full-width') : ''"
                      label="Enviar arquivo"
                    >
                    </q-btn>
                  </q-item>
                  <q-item style="padding: 0">
                    <q-btn
                      flat
                      @click="handlSendLinkVideo"
                      icon="mdi-message-video"
                      :disable="cDisableActions || desabilitarInput"
                      class="color-light1"
                      :class="$q.dark.isActive ? ('color-dark1') : ''"
                      label="Enviar videoconferência"
                    >
                    </q-btn>
                  </q-item>
                </q-list>
              </q-menu>
            </q-btn>

            <q-btn
              v-if="mensagemRapidaMedia"
              flat
              dense
              icon="mdi-cancel"
              class="bg-padrao btn-rounded q-mx-xs"

              :color="$q.dark.isActive ? 'red' : 'red'"
              @click="removerMediaMensagemRapida"
            >
              <q-tooltip content-class="text-bold"> Remover Mídia da Mensagem Rápida </q-tooltip>
            </q-btn>

            <q-input
              hide-bottom-space
              :loading="loading"
              :disable="cDisableActions"
              ref="inputEnvioMensagem"
              id="inputEnvioMensagem"
              type="textarea"
              @keydown.exact.enter.prevent="enviarMensagemOnEnter"
              v-show="ticketFocado.channel === 'whatsapp' ? !cMostrarEnvioArquivo2 : !cMostrarEnvioArquivo"
              class="col-grow q-mx-xs text-grey-10 inputEnvioMensagem"
              bg-color="grey-2"
              color="grey-7"
              placeholder="Digita sua mensagem"
              input-style="max-height: 30vh"
              autogrow
              rounded
              dense
              outlined
              v-model="textChat"
              :value="textChat"
              @paste="handleInputPaste"
            >

              <template v-slot:prepend v-if="$q.screen.width < 500">
                <q-btn  flat icon="mdi-emoticon-happy-outline" :disable="cDisableActions" dense round :color="$q.dark.isActive ? 'color-dark1' : ''">
                  <q-tooltip content-class="text-bold"> Emoji </q-tooltip>
                  <q-menu anchor="top right" self="bottom middle" :offset="[5, 40]">
                    <VEmojiPicker style="width: 40vw" :showSearch="false" :emojisByRow="calculateEmojisByRow()" labelSearch="Localizar..." lang="pt-BR" @select="onInsertSelectEmoji" />
                  </q-menu>
                </q-btn>
              </template>

              <template v-slot:append>
                <q-btn
                  flat
                  @click="abrirEnvioArquivo"
                  icon="mdi-paperclip"
                  :disable="cDisableActions"
                  dense
                  round
                  v-if="$q.screen.width < 500"
                  class="color-light1 bg-padrao full-width"
                  :class="$q.dark.isActive ? ('color-dark1 bg-padrao full-width') : ''"
                >
                  <q-tooltip content-class=" text-bold"> Enviar arquivo </q-tooltip>
                </q-btn>

                <q-toggle keep-color v-model="sign" dense @input="handleSign" class="q-mx-sm q-ml-md" :color="sign ? 'positive' : 'black'" type="toggle" v-if="userProfile === 'admin'">
                  <q-tooltip> {{ sign ? 'Desativar' : 'Ativar' }} Assinatura </q-tooltip>
                </q-toggle>
                <q-toggle keep-color v-model="sign" dense @input="handleSign" class="q-mx-sm q-ml-md" :color="sign ? 'positive' : 'black'" type="toggle" v-if="disabledSign && userProfile !== 'admin'">
                  <q-tooltip> {{ sign ? 'Desativar' : 'Ativar' }} Assinatura </q-tooltip>
                </q-toggle>

              </template>
            </q-input>

            <q-file
              :loading="loading"
              :disable="cDisableActions || desabilitarInput"
              ref="PickerFileMessage"
              id="PickerFileMessage"
              v-show="cMostrarEnvioArquivo"
              v-model="arquivos"
              class="col-grow q-mx-xs PickerFileMessage"
              bg-color="blue-grey-1"
              input-style="max-height: 30vh"
              outlined
              use-chips
              multiple
              autogrow
              dense
              rounded
              append
              :max-files="5"
              :max-file-size="ticketFocado.channel === 'hub_instagram' ? 8388608 : 52428800"
              :max-total-size="ticketFocado.channel === 'hub_instagram' ? 8388608 : 52428800"
              :accept="ticketFocado.channel === 'hub_instagram' ? '.jpeg, .png, .ico, .bmp, .webp, .*' : '.txt, .xml, .jpg, .png, image/jpeg, .pdf, .doc, .docx, .mp4, .mp3, .xls, .xlsx, .jpeg, .rar, .zip, .ppt, .pptx, image/*, .dwg, .cad, .cdr, .psd, .ai'"
              @rejected="onRejectedFiles"
            />

            <q-btn
              v-if="textChat || cMostrarEnvioArquivo || removeMedia"
              ref="btnEnviarMensagem"
              @click="enviarMensagem"
              :disabled="ticketFocado.status !== 'open'"
              flat
              icon="mdi-send"
              class="color-light1 bg-padrao btn-rounded q-mx-xs"
              :class="$q.dark.isActive ? ('color-dark1 bg-padrao btn-rounded q-mx-xs') : ''"
            >
              <q-tooltip content-class=" text-bold"> Enviar </q-tooltip>
            </q-btn>

            <q-btn
              v-if="!textChat && !cMostrarEnvioArquivo && !isRecordingAudio && ticketFocado.channel !== 'hub_instagram'"
              @click="handleStartRecordingAudio"
              :disabled="cDisableActions || desabilitarInput"
              flat
              icon="eva-mic-outline"
              class="color-light1 btn-rounded q-mx-xs"
              :class="$q.dark.isActive ? ('color-dark1 btn-rounded q-mx-xs') : ''"
            >
              <q-tooltip content-class="text-bold"> Enviar Áudio </q-tooltip>
            </q-btn>
          </template>

          <template v-else>
            <div class="full-width items-center row justify-end">
              <q-skeleton animation="pulse-y" class="col-grow q-mx-md" type="text" />
              <div style="width: 200px" class="flex flex-center items-center" v-if="isRecordingAudio">
                <q-btn flat icon="mdi-close" color="negative" @click="handleCancelRecordingAudio" class="bg-padrao btn-rounded q-mx-xs" />
                <RecordingTimer class="text-bold" :class="{ 'color-dark3': $q.dark.isActive }" />
                <q-btn flat icon="mdi-send-circle-outline" color="positive" @click="handleStopRecordingAudio" class="bg-padrao btn-rounded q-mx-xs" />
              </div>
            </div>
          </template>
        </div>

        <q-dialog v-model="abrirModalPreviewImagem" position="right" @hide="hideModalPreviewImagem" @show="showModalPreviewImagem">
          <q-card style="height: 90vh; min-width: 60vw; max-width: 60vw" class="q-pa-md">
            <q-card-section>
              <div class="text-h6">
                {{ urlMediaPreview.title }}
                <q-btn class="float-right" icon="close" color="negative" round outline @click="hideModalPreviewImagem" />
              </div>
            </q-card-section>
            <q-card-section>
              <q-img :src="urlMediaPreview.src" class="color-dark3 img-responsive mdi-image-auto-adjust q-uploader__file--img" style="height: 60vh; min-width: 55vw; max-width: 55vw" />
            </q-card-section>
            <q-card-section>
              <q-input v-model="inputText" label="Digite sua mensagem" filled dense />
            </q-card-section>
            <q-card-actions align="center">
              <q-btn ref="qbtnPasteEnvioMensagem" label="Enviar" color="primary" v-close-popup @click="enviarMensagem" @keypress.enter.exact="enviarMensagem()" />
            </q-card-actions>
            <span class="row col text-caption text-blue-grey-10">* Confirmar envio: Enter</span>
            <span class="row col text-caption text-blue-grey-10">** Cancelar: ESC</span>
          </q-card>
        </q-dialog>

      </div>

    </div>
</template>

<script>
import { LocalStorage, uid } from 'quasar'
import mixinCommon from './mixinCommon'
import { EnviarMensagemTexto } from 'src/service/tickets'
import { VEmojiPicker } from 'v-emoji-picker'
import { mapGetters } from 'vuex'
import RecordingTimer from './RecordingTimer'
import MicRecorder from 'mic-recorder-to-mp3'
const Mp3Recorder = new MicRecorder({
  bitRate: 128,
  encodeAfterRecord: true
})
import { add, format } from 'date-fns'
import { ListarConfiguracoes } from 'src/service/configuracoes'

export default {
  name: 'InputMensagem',
  mixins: [mixinCommon],
  props: {
    replyingMessage: {
      type: Object,
      default: null
    },
    isScheduleDate: {
      type: Boolean,
      default: false
    },
    mensagensRapidas: {
      type: Array,
      default: () => []
    }
  },
  components: {
    VEmojiPicker,
    RecordingTimer
  },
  data () {
    return {
      schedule: {
        selected: { label: 'Agendamento customizado', value: 'custom', func: null },
        options: [
          { label: 'Agendamento customizado', value: 'custom', func: null },
          { label: 'Em 30 minutos', value: '30_mins', func: () => add(new Date(), { minutes: 30 }) },
          { label: 'Amanhã', value: 'amanha', func: () => add(new Date(), { days: 1 }) },
          { label: 'Próxima semana', value: 'prox_semana', func: () => add(new Date(), { weeks: 1 }) }
        ]
      },
      loading: false,
      inputText: '',
      abrirFilePicker: false,
      abrirModalPreviewImagem: false,
      isRecordingAudio: false,
      urlMediaPreview: {
        title: '',
        src: ''
      },
      visualizarMensagensRapidas: false,
      arquivos: [],
      textChat: '',
      isSending: false,
      sign: false,
      scheduleDate: null,
      userProfile: 'user',
      mensagemRapidaMedia: '',
      mensagemRapidaSetada: false,
      removeMedia: false,
      disabledSign: false
    }
  },
  computed: {
    ...mapGetters(['ticketFocado']),
    cMostrarEnvioArquivo () {
      return this.arquivos.length > 0
    },
    cMostrarEnvioArquivo2 () {
      return this.arquivos.length > 1
    },
    cDisableActions () {
      return (this.isRecordingAudio || this.ticketFocado.status !== 'open')
    },
    cMensagensRapidas () {
      let search = this.textChat?.toLowerCase()
      if (search && search.trim().startsWith('/')) {
        search = search.replace('/', '')
      }
      return !search ? this.mensagensRapidas : this.mensagensRapidas.filter(r => r.key.toLowerCase().indexOf(search) !== -1)
      // return this.mensagensRapidas
    }
  },
  methods: {
    onSelectSchedule(newValue) {
      if (!newValue.func) {
        this.scheduleDate = null
        return
      }
      const date = newValue.func()
      this.scheduleDate = format(date, 'yyyy-MM-dd HH:mm')
    },
    async enviarMensagemOnEnter() {
      if (this.isSending || !this.textChat.trim()) return

      this.isSending = true

      try {
        await this.enviarMensagem()
      } catch (error) {
        console.error('Erro ao enviar mensagem:', error)
      } finally {
        this.isSending = false
      }
    },
    handleFileDrop(event) {
      const files = event.dataTransfer.files
      if (files.length) {
        this.textChat = ''
        this.arquivos = [files[0]]
        this.abrirModalPreviewImagem = true
        this.urlMediaPreview = {
          title: `Enviar imagem para ${this.ticketFocado?.contact?.name}`,
          src: this.openFilePreviewDD(files[0])
        }
        this.$refs.inputEnvioMensagem.focus()
      }
    },
    handleDragOver(event) {
      event.preventDefault()
      event.currentTarget.classList.add('dragover')
    },
    handleDragLeave(event) {
      event.currentTarget.classList.remove('dragover')
    },
    openFilePreviewDD(file) {
      const urlImg = window.URL.createObjectURL(file)
      return urlImg
    },
    async listarConfiguracoes() {
      const { data } = await ListarConfiguracoes()
      this.configuracoes = data
      this.configuracoes.forEach(el => {
        let value = el.value
        if (el.key === 'botTicketActive' && el.value) {
          value = +el.value
        }
        this.$data[el.key] = value
      })
      const enabledSign = this.configuracoes.filter(item => item.key === 'userDisableSignature')[0]
      if (enabledSign.value === 'enabled') {
        this.disabledSign = true
      } else {
        LocalStorage.set('sign', true)
        this.disabledSign = false
      }
    },
    openFilePreview (event) {
      const data = event.clipboardData.files[0]
      const urlImg = window.URL.createObjectURL(data)
      return urlImg
    },
    handleInputDrop(evt) {
      const allowed = this.accept.split(',').map((a) => a.trim())
      this.textChat = ''
      this.arquivos = [
        ...this.arquivos,
        ...[...evt.dataTransfer.files].filter((file) => {
          const ext = file.name.split('.').pop()
          const extensionPattern = allowed.map((ext) => ext.replace(/\./g, '\\.').replace(/\*/g, '.*')).join('|')
          const regex = new RegExp(`^(${extensionPattern})$`, 'i')
          return regex.test(file.type) || regex.test('.' + ext)
        })
      ]

      if (!this.arquivos.length) {
        this.$q.notify({
          message: 'Arquivo inválido!',
          caption: `Formatos aceitos: ${allowed.join(', ')}`,
          type: 'negative'
        })
        return
      }

      this.$refs.inputEnvioMensagem.focus()
    },
    handleInputPaste (e) {
      if (!this.ticketFocado?.id) return
      if (e.clipboardData.files[0]) {
        this.textChat = ''
        this.arquivos = [e.clipboardData.files[0]]
        this.abrirModalPreviewImagem = true
        this.urlMediaPreview = {
          title: `Enviar imagem para ${this.ticketFocado?.contact?.name}`,
          src: this.openFilePreview(e)
        }
        this.$refs.inputEnvioMensagem.focus()
      }
    },
    removerMediaMensagemRapida() {
      this.removeMedia = false
      this.mensagemRapidaMedia = ''
      this.mensagemRapidaSetada = false
    },
    mensagemRapidaSelecionada(mensagem) {
      if (mensagem.message !== 'null') {
        this.textChat = mensagem.message
      }
      if (this.mensagemRapidaMedia !== null) {
        this.mensagemRapidaMedia = mensagem.media
        this.removeMedia = true
      }
      if (this.mensagemRapidaMedia !== null) {
        this.mensagemRapidaSetada = true
        this.removeMedia = true
      }
      setTimeout(() => {
        this.$refs.inputEnvioMensagem.focus()
      }, 300)
    },
    onInsertSelectEmoji (emoji) {
      const self = this
      var tArea = this.$refs.inputEnvioMensagem.$refs.input
      // get cursor's position:
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value

      // filter:
      if (!emoji.data) {
        return
      }

      // insert:
      self.txtContent = this.textChat
      self.txtContent = tmpStr.substring(0, startPos) + emoji.data + tmpStr.substring(endPos, tmpStr.length)
      this.textChat = self.txtContent
      // move cursor:
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + emoji.data.length
      }, 10)
    },
    abrirEnvioArquivo (event) {
      this.textChat = ''
      this.abrirFilePicker = true
      this.$refs.PickerFileMessage.pickFiles(event)
    },
    async handleStartRecordingAudio () {
      try {
        await navigator.mediaDevices.getUserMedia({ audio: true })
        await Mp3Recorder.start()
        this.isRecordingAudio = true
      } catch (error) {
        this.isRecordingAudio = false
      }
    },
    async handleStopRecordingAudio () {
      const ticketId = this.ticketFocado.id
      this.loading = true
      this.isRecordingAudio = false
      try {
        const [, blob] = await Mp3Recorder.stop().getMp3()
        if (blob.size < 10000) {
          this.loading = false
          return
        }
        const username = localStorage.getItem('username')

        const sendType = 'user: ' + username

        const formData = new FormData()
        const filename = `${new Date().getTime()}.mp3`
        formData.append('medias', blob, filename)
        formData.append('body', '')
        formData.append('sendType', sendType)
        formData.append('fromMe', true)
        if (this.isScheduleDate) {
          formData.append('scheduleDate', this.scheduleDate)
        }

        await EnviarMensagemTexto(ticketId, formData)
        this.arquivos = []
        this.textChat = ''
        this.$emit('update:replyingMessage', null)
        this.abrirFilePicker = false
        this.abrirModalPreviewImagem = false
        this.isRecordingAudio = false
        this.loading = false
        setTimeout(() => {
          this.scrollToBottom()
        }, 300)
      } catch (error) {
        this.isRecordingAudio = false
        this.loading = false
        this.$notificarErro('Ocorreu um erro!', error)
      }
    },
    async handleCancelRecordingAudio () {
      try {
        await Mp3Recorder.stop().getMp3()
        this.isRecordingAudio = false
        this.loading = false
      } catch (error) {
        this.$notificarErro('Ocorreu um erro!', error)
      }
    },
    prepararUploadMedia() {
      if (!this.arquivos.length) {
        throw new Error('Não existem arquivos para envio')
      }

      const formData = new FormData()
      formData.append('fromMe', true)

      const bodyText = this.inputText && this.inputText.trim()
        ? this.inputText.trim()
        : this.textChat && this.textChat.trim()
          ? this.prepararMensagemTexto().body
          : null

      const username = localStorage.getItem('username')

      const sendType = 'user: ' + username

      this.arquivos.forEach((media) => {
        formData.append('medias', media)
        formData.append('body', bodyText || '')
        formData.append('sendType', sendType)
        formData.append('idFront', uid())

        if (this.isScheduleDate) {
          formData.append('scheduleDate', this.scheduleDate)
        }
      })

      return formData
    },
    prepararMensagemTexto () {
      if (this.textChat.trim() === '' && !this.removeMedia) {
        throw new Error('Mensagem Inexistente')
      }

      if (this.textChat.trim() && this.textChat.trim().startsWith('/')) {
        let search = this.textChat.trim().toLowerCase()
        search = search.replace('/', '')
        const mensagemRapida = this.cMensagensRapidas.find(m => m.key.toLowerCase() === search)
        if (mensagemRapida?.message) {
          this.textChat = mensagemRapida.message
        } else {
          const error = this.cMensagensRapidas.length > 1
            ? 'Várias mensagens rápidas encontradas. Selecione uma ou digite uma chave única da mensagem.'
            : '/ indica que você deseja enviar uma mensagem rápida, mas nenhuma foi localizada. Cadastre ou apague a / e digite sua mensagem.'
          this.$notificarErro(error)
          this.loading = false
          console.error(error)
          throw new Error(error)
        }
      }

      let mensagem = this.textChat.trim()
      const username = localStorage.getItem('username')
      if (username && this.sign) {
        mensagem = `*${username}*:\n${mensagem}`
      }

      const sendType = 'user: ' + username

      const message = {
        read: 1,
        fromMe: true,
        mediaUrl: this.mensagemRapidaSetada ? `${this.mensagemRapidaMedia}` : '',
        body: mensagem,
        sendType: sendType,
        scheduleDate: this.isScheduleDate ? this.scheduleDate : null,
        quotedMsg: this.replyingMessage,
        idFront: uid()
      }

      if (this.isScheduleDate) {
        message.scheduleDate = this.scheduleDate
      }

      return message
    },
    async enviarMensagem() {
      const ticketId = this.ticketFocado.id
      if (this.isScheduleDate && !this.scheduleDate) {
        this.$notificarErro('Para agendar uma mensagem, informe o campo Data/Hora Agendamento.')
        return
      }

      this.loading = true

      if (this.mensagemRapidaSetada) {
        this.cMostrarEnvioArquivo = false
      }

      const message = !this.cMostrarEnvioArquivo
        ? this.prepararMensagemTexto()
        : this.prepararUploadMedia()

      try {
        if (!this.cMostrarEnvioArquivo && !this.textChat && !this.removeMedia) return

        await EnviarMensagemTexto(ticketId, message)
        this.arquivos = []
        this.textChat = ''
        this.inputText = ''
        this.$emit('update:replyingMessage', null)
        this.abrirFilePicker = false
        this.abrirModalPreviewImagem = false

        setTimeout(() => {
          this.scrollToBottom()
        }, 300)
      } catch (error) {
        this.isRecordingAudio = false
        this.removeMedia = false
        this.mensagemRapidaMedia = ''
        this.mensagemRapidaSetada = false
        this.loading = false
        this.$notificarErro('Ocorreu um erro!', error)
        console.error('Erro ao enviar mensagem:', error)
      }

      this.removeMedia = false
      this.mensagemRapidaMedia = ''
      this.mensagemRapidaSetada = false
      this.isRecordingAudio = false
      this.loading = false

      setTimeout(() => {
        this.$refs.inputEnvioMensagem.focus()
      }, 300)
    },
    async handlSendLinkVideo () {
      const ticketId = this.ticketFocado.id
      const link = `https://meet.jit.si/${uid()}/${uid()}`
      let mensagem = link
      const username = localStorage.getItem('username')
      if (username && this.sign) {
        mensagem = `*${username}*:\n ${mensagem}`
      }

      const sendType = 'user: ' + username

      const message = {
        read: 1,
        fromMe: true,
        mediaUrl: '',
        sendType: sendType,
        body: mensagem,
        scheduleDate: this.isScheduleDate ? this.scheduleDate : null,
        quotedMsg: this.replyingMessage,
        idFront: uid(),
        ticket: this.ticketFocado,
        group: this.ticketFocado.isGroup
      }

      this.loading = true
      try {
        await EnviarMensagemTexto(ticketId, message)
        setTimeout(() => {
          this.scrollToBottom()
        }, 200)
        setTimeout(() => {
          window.open(link, '_blank')
        }, 800)
      } catch (error) {
        this.loading = false
        this.$notificarErro('Ocorreu um erro!', error)
      }
      this.loading = false
    },
    handlerInputMensagem (v) {
      this.textChat = v.target.value
    },
    showModalPreviewImagem () {
      this.$nextTick(() => {
        setTimeout(() => {
          this.$refs.qbtnPasteEnvioMensagem.$el.focus()
        }, 20)
      })
    },
    hideModalPreviewImagem () {
      this.arquivos = []
      this.urlMediaPreview = {}
      this.abrirModalPreviewImagem = false
    },
    onRejectedFiles (rejectedEntries) {
      let message

      if (this.ticketFocado.channel === 'hub_instagram') {
        message = `Ops... Ocorreu um erro! <br>
    <ul>
    <li>Cada arquivo deve ter no máximo 8MB.</li>
    <li>Apenas arquivos nos formatos .jpeg, .png, .ico, .bmp, .webp e .* são aceitos.</li>
    </ul>`
      } else {
        message = `Ops... Ocorreu um erro! <br>
    <ul>
    <li>Verique o tamanho do arquivo.</li>
    <li>Em caso de múltiplos arquivos, o tamanho total (soma de todos) deve ser de até 50MB.</li>
    </ul>`
      }
      this.$q.notify({
        html: true,
        message: message,
        type: 'negative',
        progress: true,
        position: 'top',
        actions: [{
          icon: 'close',
          round: true,
          color: 'white'
        }]
      })
    },
    onResize() {
      this.$forceUpdate()
    },
    calculateEmojisByRow() {
      const screenWidth = window.innerWidth
      if (screenWidth < 600) {
        return 5
      } else if (screenWidth >= 600 && screenWidth < 1200) {
        return 10
      } else {
        return 20
      }
    },
    getBadgeClass(index) {
      const colors = ['bg-green-6', 'bg-orange-6', 'bg-teal-6', 'bg-blue-6', 'bg-deep-purple-6', 'bg-yellow-6', 'bg-brown-6', 'bg-cyan-6']
      const colorIndex = index % 8
      // console.log(index);
      return colors[colorIndex]
    },
    handleSign (state) {
      this.sign = state
      LocalStorage.set('sign', this.sign)
    }
  },
  mounted () {
    this.$root.$on('mensagem-chat:focar-input-mensagem', () => this.$refs.inputEnvioMensagem.focus())
    const self = this
    window.addEventListener('paste', self.handleInputPaste)
    this.listarConfiguracoes()
    this.userProfile = localStorage.getItem('profile')
    if (![null, undefined].includes(LocalStorage.getItem('sign'))) {
      this.handleSign(LocalStorage.getItem('sign'))
    }
  },
  beforeDestroy () {
    const self = this
    window.removeEventListener('paste', self.handleInputPaste)
  },
  destroyed () {
    this.$root.$off('mensagem-chat:focar-input-mensagem')
  }
}
</script>

<style lang="sass" scoped>
@media (max-width: 850px)
  .inputEnvioMensagem,
  .PickerFileMessage
    width: 150px

@media (min-width: 851px), (max-width: 1360px)
  .inputEnvioMensagem,
  .PickerFileMessage
    width: 200px !important

.emoji-picker
  width: 100%

@media (min-width: 600px)
  .emoji-picker
    width: 50vw

</style>
